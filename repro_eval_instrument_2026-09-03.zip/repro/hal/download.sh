#!/bin/bash
WD=/PATH/TO/probes/hal
LIST="$WD/$1"
cd $WD/raw
MIRROR="https://hf-mirror.com/datasets/agent-evals/hal_traces/resolve/main"
while read -r f; do
  [ -z "$f" ] && continue
  if [ -s "$f" ]; then echo "SKIP $f"; continue; fi
  if curl -sL --retry 3 -m 3600 -o "$f.part" "$MIRROR/$f?download=true"; then mv "$f.part" "$f"; echo "OK $f $(stat -c%s "$f")"; else echo "FAIL $f"; fi
done < "$LIST"
echo "DONE_LIST $1"

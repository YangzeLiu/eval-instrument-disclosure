import zipfile, json, base64, os, re
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

WD = os.environ.get("HAL_PROBE_DIR", "/PATH/TO/probes/hal")

def load(path):
    zf = zipfile.ZipFile(path, 'r')
    e = json.loads(zf.read(zf.namelist()[0])); zf.close()
    salt = base64.b64decode(e['salt'])
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=480000)
    # The passphrase is the constant hard-coded in HAL's published hal-decrypt.sh
    # (princeton-pli/hal-harness). Export it as HAL_DECRYPT_PASSPHRASE before running.
    pw = os.environ.get('HAL_DECRYPT_PASSPHRASE')
    if not pw: raise SystemExit('set HAL_DECRYPT_PASSPHRASE (see hal-decrypt.sh in hal-harness)')
    key = base64.urlsafe_b64encode(kdf.derive(pw.encode()))
    return json.loads(Fernet(key).decrypt(base64.b64decode(e['encrypted_data'])))

def walk_types(o, prefix="", depth=0, out=None, maxd=4):
    if out is None: out = []
    if depth > maxd: return out
    if isinstance(o, dict):
        ks = list(o.keys())
        out.append((prefix, 'dict', len(ks), ks[:6]))
        if ks:
            # descend into first value only (assume homogeneous)
            walk_types(o[ks[0]], prefix + "." + str(ks[0]), depth+1, out, maxd)
    elif isinstance(o, list):
        out.append((prefix, 'list', len(o), []))
        if o: walk_types(o[0], prefix + "[0]", depth+1, out, maxd)
    else:
        out.append((prefix, type(o).__name__, 0, [repr(o)[:60]]))
    return out

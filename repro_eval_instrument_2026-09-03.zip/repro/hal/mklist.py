import json,os
WD="/PATH/TO/probes/hal"
F=json.load(open(WD+"/files.json"))
if isinstance(F,dict): F=F.get("files") or list(F.values())[0]
have=set(os.listdir(WD+"/raw"))
for pref,tag in (("scicode","sci"),("swebench","swe")):
    sel=[]
    for f in F:
        p=f.get("path") or f.get("rfilename") or ""
        if p.endswith(".zip") and p.startswith(pref) and p not in have:
            sel.append((p,f.get("size") or (f.get("lfs") or {}).get("size") or 0))
    sel.sort(key=lambda z:z[1])
    print(tag,len(sel),"%.2f GB"%(sum(s for _,s in sel)/1e9))
    for i in range(4):
        with open(f"{WD}/dl_{tag}{i}.txt","w") as w:
            for p,_ in sel[i::4]: w.write(p+"\n")

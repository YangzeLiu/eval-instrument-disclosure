import sys, types, glob, os, json, collections, statistics as st
import multiprocessing as mp
m=types.ModuleType("litellm"); m.completion=lambda *a,**k:None; sys.modules["litellm"]=m
WD="/PATH/TO/probes/hal"
TB=WD+"/taubench/tau-bench-14bf0ef52e595922d597a38f32d3e8c0dce3a8f8"
sys.path.insert(0,TB); sys.path.insert(0,WD+"/scripts")
from halio import load
TERM={"transfer_to_human_agents"}
WRITE={"book_reservation","cancel_reservation","send_certificate",
       "update_reservation_baggages","update_reservation_flights","update_reservation_passengers"}

def one(z):
    try: d=load(z)
    except Exception: return None
    cfg=d.get("config") or {}
    an=cfg.get("agent_name") or ""
    sc="GEN" if "Generalist" in an else ("FEWSHOT" if "hot" in an.lower() else "TOOLCALL")
    rer=d.get("raw_eval_results") or {}
    if not isinstance(rer,dict): return None
    out=[]
    for tid,v in rer.items():
        if not isinstance(v,dict): continue
        t=v.get("task"); ta=v.get("taken_actions")
        if not isinstance(t,dict) or not isinstance(ta,list): continue
        gold=[(x.get("name"),x.get("kwargs")) for x in (t.get("actions") or []) if x.get("name") not in TERM]
        got=[x for x in ta if isinstance(x,dict)]
        gk=[(x.get("name"),x.get("kwargs")) for x in got]
        n=len(gold); leak = n>=1 and len(gk)>=n and gk[-n:]==gold
        own=got[:-n] if leak else got
        allnames=[x.get("name") for x in got]
        ownnames=[x.get("name") for x in own]
        certs=[(x.get("kwargs") or {}).get("amount") for x in own if x.get("name")=="send_certificate"]
        certs_raw=[(x.get("kwargs") or {}).get("amount") for x in got if x.get("name")=="send_certificate"]
        out.append(dict(sc=sc,task=int(tid),leak=leak,rw=float(v.get("reward") or 0),
            gold_transfer_only=(n==0 and any(a.get("name") in TERM for a in (t.get("actions") or []))),
            own=ownnames, allnames=allnames, certs=certs, certs_raw=certs_raw))
    return (os.path.basename(z),sc,out)

if __name__=="__main__":
    zs=sorted(glob.glob(WD+"/raw/*taubench_airline*.zip"))
    with mp.Pool(8) as p: res=[x for x in p.map(one,zs) if x]
    recs=[(f,sc,r) for f,sc,rs in res for r in rs]
    print("runs %d records %d"%(len(res),len(recs)))
    # ---- 1. structural table (per task means), agent-only vs raw
    print()
    print("STRUCTURAL TABLE  (per task-record means; reads = non-write tool calls excluding think/transfer)")
    print("%-9s %6s | %6s %6s %6s | %6s %6s %6s"%("scaffold","n","reads","respond","writes","reads_raw","resp_raw","writes_raw"))
    by=collections.defaultdict(list)
    for f,sc,r in recs: by[sc].append(r)
    for sc in ("GEN","FEWSHOT","TOOLCALL"):
        s=by[sc]
        def mn(f): return sum(f(r) for r in s)/len(s)
        rd=lambda ns:sum(1 for x in ns if x not in WRITE and x not in TERM and x not in ("respond","think"))
        print("%-9s %6d | %6.2f %6.2f %6.2f | %6.2f %6.2f %6.2f"%(sc,len(s),
            mn(lambda r: rd(r["own"])), mn(lambda r: r["own"].count("respond")),
            mn(lambda r: sum(1 for x in r["own"] if x in WRITE)),
            mn(lambda r: rd(r["allnames"])), mn(lambda r: r["allnames"].count("respond")),
            mn(lambda r: sum(1 for x in r["allnames"] if x in WRITE))))
    # ---- 2. task 46 certificate table
    for TASK in (46,):
        print(); print("TASK %d certificate table (agent-only | raw)"%TASK)
        t46=[r for f,sc,r in recs if r["task"]==TASK]
        for label,key in (("AGENT-ONLY","certs"),("RAW (as in FU3)","certs_raw")):
            c=collections.defaultdict(lambda:[0,0.0])
            for r in t46:
                k=(len(r[key]), tuple(sorted(x for x in r[key] if x is not None)))
                c[k][0]+=1; c[k][1]+=r["rw"]
            print("  %s:"%label)
            for k in sorted(c): print("    n_cert=%d amounts=%s  runs=%d  mean_reward=%.2f"%(k[0],k[1],c[k][0],c[k][1]/c[k][0]))
        print("  per scaffold (agent-only): ")
        for sc in ("GEN","FEWSHOT","TOOLCALL"):
            s=[r for r in t46 if r["sc"]==sc]
            if not s: continue
            print("    %-9s runs=%2d mean_certs=%.2f (raw %.2f)  mean_reward=%.2f"%(sc,len(s),
                sum(len(r["certs"]) for r in s)/len(s), sum(len(r["certs_raw"]) for r in s)/len(s),
                sum(r["rw"] for r in s)/len(s)))
    # ---- 3. task 36 and 38
    for TASK in (36,38):
        print(); print("TASK %d"%TASK)
        t=[r for f,sc,r in recs if r["task"]==TASK]
        nw=sum(1 for r in t if sum(1 for x in r["own"] if x in WRITE)==0)
        nwr=sum(1 for r in t if sum(1 for x in r["allnames"] if x in WRITE)==0)
        print("  runs=%d ; no write action: agent-only %d, raw %d ; mean reward when no write=%.2f"%(
            len(t),nw,nwr,sum(r["rw"] for r in t if sum(1 for x in r["own"] if x in WRITE)==0)/max(1,nw)))
        for sc in ("GEN","FEWSHOT","TOOLCALL"):
            s=[r for r in t if r["sc"]==sc]
            if not s: continue
            print("    %-9s runs=%2d acc=%.3f  respond(agent-only)=%.1f (raw %.1f)  transfer=%d/%d"%(sc,len(s),
                sum(r["rw"]>0 for r in s)/len(s),
                sum(r["own"].count("respond") for r in s)/len(s),
                sum(r["allnames"].count("respond") for r in s)/len(s),
                sum(1 for r in s if any(x in TERM for x in r["own"])),len(s)))
    # ---- 4. transfer-only generalisation
    print(); print("ALL transfer-only-gold items (agent-only actions; no injection possible on these)")
    for sc in ("GEN","FEWSHOT","TOOLCALL"):
        s=[r for f,s2,r in recs if r["sc"]==sc and r["gold_transfer_only"]]
        if not s: continue
        tr=[r for r in s if any(x in TERM for x in r["own"])]; nt=[r for r in s if r not in tr]
        print("  %-9s n=%3d transfer=%.1f%%  reward|transfer=%.3f  reward|no-transfer=%.3f"%(sc,len(s),
            100*len(tr)/len(s), sum(r["rw"] for r in tr)/max(1,len(tr)), sum(r["rw"] for r in nt)/max(1,len(nt))))

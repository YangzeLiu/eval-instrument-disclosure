import sys,types,json,glob,os,collections,random
class _F:
    def __getattr__(self,k): return _F()
    def __getitem__(self,k): return _F()
    def __iter__(self): return iter([_F()])
    def __call__(self,*a,**k): return {"role":"user","content":""}
    def __str__(self): return ""
    def __float__(self): return 0.0
m=types.ModuleType("litellm"); m.completion=lambda *a,**k:_F(); sys.modules["litellm"]=m
WD="/PATH/TO/probes/hal"
TB=WD+"/taubench/tau-bench-14bf0ef52e595922d597a38f32d3e8c0dce3a8f8"
sys.path.insert(0,TB); sys.path.insert(0,WD+"/scripts")
from tau_bench.envs.airline import MockAirlineDomainEnv
from tau_bench.envs import user as _u
_u.LLMUserSimulationEnv.generate_next_message=lambda self,msgs:""
_u.LLMUserSimulationEnv.get_total_cost=lambda self:0.0
_u.LLMUserSimulationEnv.step=lambda self,c:""
from tau_bench.types import Action
from halio import load
TERM={"transfer_to_human_agents"}

def env(i):
    e=MockAirlineDomainEnv(user_strategy="llm",user_model="gpt-4o",user_provider="openai",task_split="test",task_index=i)
    e.reset(task_index=i); return e

def score(i,actions):
    e=env(i)
    for a in actions:
        nm=a.get("name")
        if nm=="respond": e.actions.append(Action(name="respond",kwargs=a.get("kwargs") or {})); continue
        if nm in TERM: e.actions.append(Action(name=nm,kwargs=a.get("kwargs") or {})); continue
        try: e.step(Action(name=nm,kwargs=a.get("kwargs") or {}))
        except Exception: pass
    return e.calculate_reward().reward

recs=[]
for z in sorted(glob.glob(WD+"/raw/*taubench_airline*.zip")):
    try: d=load(z)
    except Exception: continue
    a=(d.get("config",{}) or {}).get("agent_name") or ""
    sc="GEN" if "Generalist" in a else ("FEWSHOT" if "hot" in a.lower() else "TOOLCALL")
    rer=d.get("raw_eval_results") or {}
    if not isinstance(rer,dict): continue
    for tid,v in rer.items():
        if not isinstance(v,dict): continue
        t=v.get("task"); ta=v.get("taken_actions")
        if not isinstance(t,dict) or not isinstance(ta,list): continue
        gold=[(x.get("name"),x.get("kwargs")) for x in (t.get("actions") or []) if x.get("name") not in TERM]
        got=[x for x in ta if isinstance(x,dict)]
        gk=[(x.get("name"),x.get("kwargs")) for x in got]
        n=len(gold)
        if n<2 or len(gk)<n or gk[-n:]!=gold: continue
        recs.append((sc,int(tid),float(v.get("reward") or 0),got,n))
random.seed(0); random.shuffle(recs); recs=recs[:600]
st=collections.Counter()
for sc,tid,rw,got,n in recs:
    try:
        full=score(tid,got); own=score(tid,got[:-n])
    except Exception as e:
        st["err"]+=1; continue
    st[("full",  (full>0)==(rw>0))]+=1
    st[("stripped",(own>0)==(rw>0))]+=1
    st[(sc,"stripped",(own>0)==(rw>0))]+=1
print("replayed records:",len(recs),"errors:",st["err"])
for k in ("full","stripped"):
    ok=st[(k,True)]; bad=st[(k,False)]
    print("  %-9s reproduces recorded reward: %d/%d = %.1f%%"%(k,ok,ok+bad,100*ok/max(1,ok+bad)))
for sc in ("FEWSHOT","TOOLCALL","GEN"):
    ok=st[(sc,"stripped",True)]; bad=st[(sc,"stripped",False)]
    if ok+bad: print("    %-8s stripped match %d/%d = %.1f%%"%(sc,ok,ok+bad,100*ok/(ok+bad)))

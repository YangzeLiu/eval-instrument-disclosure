import glob, os, json, collections, multiprocessing as mp
from halio import load, WD

def one(p):
    d=load(p); cfg=d.get('config') or {}
    L=d.get('raw_logging_results') or []
    ids={x['id'] for x in L}
    def agg(xs):
        s=collections.defaultdict(lambda:[0,0])
        for x in xs:
            for m,v in ((x.get('summary') or {}).get('usage') or {}).items():
                s[m][0]+=v.get('prompt_tokens',0) or 0
                s[m][1]+=v.get('completion_tokens',0) or 0
        return {k:v for k,v in s.items()}
    A=agg(L); R=agg([x for x in L if x.get('parent_id') not in ids])
    tu=d.get('total_usage') or {}
    tu2={k:[v.get('prompt_tokens',0) or 0, v.get('completion_tokens',0) or 0] for k,v in tu.items()}
    # does HAL total_usage equal the ALL-calls sum?
    match_all = (tu2==A); match_root=(tu2==R)
    # nested pairs sharing the same response id
    byid={x['id']:x for x in L}; same=0; pairs=0
    for x in L:
        pa=byid.get(x.get('parent_id'))
        if pa is None: continue
        pairs+=1
        a=(x.get('output') or {}).get('id'); b=(pa.get('output') or {}).get('id')
        if a is not None and a==b: same+=1
    tot_all=sum(v[0]+v[1] for v in A.values()); tot_root=sum(v[0]+v[1] for v in R.values())
    return dict(file=os.path.basename(p), run_id=cfg.get('run_id'),
        benchmark=cfg.get('benchmark_name'), agent_name=cfg.get('agent_name'),
        model=(cfg.get('agent_args') or {}).get('model_name'),
        hal_total_cost=d.get('total_cost'),
        n_calls=len(L), n_nested=pairs, n_nested_same_response_id=same,
        tok_all=tot_all, tok_root=tot_root,
        inflation=(tot_all/tot_root if tot_root else None),
        total_usage_equals_all=match_all, total_usage_equals_root=match_root,
        per_model_all=A, per_model_root=R)

if __name__=='__main__':
    files=sorted(glob.glob(f"{WD}/raw/*.zip"))
    with mp.Pool(12) as pool:
        out=list(pool.imap_unordered(one, files))
    json.dump(out, open(f"{WD}/dupcost.json","w"), indent=1, default=str)
    import pandas as pd
    df=pd.DataFrame([{k:v for k,v in o.items() if not k.startswith('per_model')} for o in out])
    df.to_csv(f"{WD}/dupcost.csv", index=False)
    n=len(df); wl=df[df.n_calls>0]
    print("runs:",n," with logs:",len(wl))
    print("total_usage == ALL-calls sum :", int(wl.total_usage_equals_all.sum()), "/", len(wl))
    print("total_usage == ROOT-only sum :", int(wl.total_usage_equals_root.sum()), "/", len(wl))
    print("nested pairs total:", int(df.n_nested.sum()), " of which same response id:", int(df.n_nested_same_response_id.sum()))
    print("\ninflation factor (ALL/ROOT tokens) distribution:")
    print(wl.inflation.describe().round(3).to_string())
    print("\nruns by inflation bucket:")
    import numpy as np
    b=pd.cut(wl.inflation,[0.99,1.001,1.2,1.5,1.9,1.999,2.001,10])
    print(wl.groupby(b, observed=True).agg(runs=('file','size'), hal_cost=('hal_total_cost','sum')).round(2).to_string())
    print("\nby benchmark x agent:")
    print(wl.groupby(['benchmark','agent_name']).agg(runs=('file','size'),mean_infl=('inflation','mean'),
        hal_cost=('hal_total_cost','sum')).sort_values('mean_infl',ascending=False).round(3).head(40).to_string())
    aff=wl[wl.inflation>1.9]
    print(f"\nRUNS WITH ~2x INFLATION: {len(aff)} / {len(wl)}")
    print("  HAL-reported cost of those runs: $%.2f ; true (deduped) ~ $%.2f" % (aff.hal_total_cost.sum(), (aff.hal_total_cost/aff.inflation).sum()))
    print("  overstatement: $%.2f" % (aff.hal_total_cost.sum()-(aff.hal_total_cost/aff.inflation).sum()))
    allw=wl.dropna(subset=['inflation'])
    print("ALL RUNS: HAL $%.2f -> deduped $%.2f (%.1f%% overstated)" % (
        allw.hal_total_cost.sum(), (allw.hal_total_cost/allw.inflation).sum(),
        100*(allw.hal_total_cost.sum()/(allw.hal_total_cost/allw.inflation).sum()-1)))

import re, json, sys, urllib.request, html, os
BASE="https://hal.cs.princeton.edu"
BM=["assistantbench","corebench_hard","gaia","online_mind2web","scicode",
    "scienceagentbench","swebench_verified_mini","taubench_airline","usaco"]
WD="/PATH/TO/probes/hal"
os.makedirs(f"{WD}/pages",exist_ok=True)
rows=[]
for b in BM:
    p=f"{WD}/pages/{b}.html"
    if not os.path.exists(p):
        d=urllib.request.urlopen(f"{BASE}/{b}",timeout=90).read().decode('utf-8','replace')
        open(p,'w').write(d)
    d=open(p).read()
    i=d.find('<tbody'); j=d.find('</tbody>',i)
    body=d[i:j]
    for tr in re.split(r'<tr[^>]*>', body)[1:]:
        tds=re.findall(r'<td[^>]*>(.*?)</td>', tr, re.S)
        if len(tds)<4: continue
        def txt(s): return html.unescape(re.sub(r'<[^>]+>',' ',s)).strip()
        agent=txt(tds[1]).replace('Pareto optimal','').strip()
        models=txt(tds[2])
        traces=re.search(r'href="(https://huggingface[^"]+)"', tr)
        nums=[txt(t) for t in tds[3:]]
        rows.append(dict(benchmark=b, agent=agent, models=models,
                         cells=nums, traces=traces.group(1) if traces else None))
json.dump(rows, open(f"{WD}/recon_leaderboard.json","w"), indent=1)
print("rows", len(rows))
# header names
for b in BM:
    d=open(f"{WD}/pages/{b}.html").read()
    i=d.find('<thead'); j=d.find('</thead>',i)
    ths=[html.unescape(re.sub(r'<[^>]+>',' ',t)).strip() for t in re.findall(r'<th[^>]*>(.*?)</th>', d[i:j], re.S)]
    n=sum(1 for r in rows if r['benchmark']==b)
    print(f"{b:26s} n_lb={n:3d} cols={ths}")

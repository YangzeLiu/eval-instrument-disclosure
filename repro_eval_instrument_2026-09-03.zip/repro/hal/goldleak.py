import sys, json, glob, os, collections
sys.path.insert(0, "/PATH/TO/probes/hal/scripts")
from halio import load
WD = "/PATH/TO/probes/hal"
TERM = {"transfer_to_human_agents"}

rows = []
for z in sorted(glob.glob(WD + "/raw/*taubench*.zip")):
    try:
        d = load(z)
    except Exception:
        continue
    cfg = d.get("config", {}) or {}
    agent = cfg.get("agent_name") or ""
    bench = cfg.get("benchmark_name") or ""
    rer = d.get("raw_eval_results") or {}
    if not isinstance(rer, dict):
        continue
    for tid, v in rer.items():
        if not isinstance(v, dict):
            continue
        t = v.get("task")
        ta = v.get("taken_actions")
        if not isinstance(t, dict) or not isinstance(ta, list):
            continue
        gold = [(a.get("name"), a.get("kwargs")) for a in (t.get("actions") or [])
                if a.get("name") not in TERM]
        got = [(a.get("name"), a.get("kwargs")) for a in ta if isinstance(a, dict)]
        n = len(gold)
        leak = n > 0 and len(got) >= n and got[-n:] == gold
        agent_only = got[:-n] if leak else got
        n_tools = sum(1 for a in agent_only if a[0] not in ("respond", "think"))
        rows.append(dict(zipf=os.path.basename(z), bench=bench, agent=agent, tid=tid,
                         reward=v.get("reward"), n_gold=n, n_taken=len(got),
                         leak=leak, n_agent_tool=n_tools,
                         gold_has_respond=any(g[0] == "respond" for g in gold),
                         empty_agent=(leak and n_tools == 0)))

import csv
with open(WD + "/gold_leak.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader(); w.writerows(rows)

print("records:", len(rows), "| runs:", len({r['zipf'] for r in rows}))
tot = len(rows); lk = sum(r["leak"] for r in rows)
print("gold-suffix present: %d/%d = %.1f%%" % (lk, tot, 100*lk/tot))
gz = [r for r in rows if r["n_gold"] > 0]
print("records with non-empty gold: %d ; leak among them %.1f%%" % (len(gz), 100*sum(r['leak'] for r in gz)/max(1,len(gz))))
print("mean gold actions appended (leaked recs): %.2f ; mean n_taken %.2f -> inflation %.1f%%" % (
    sum(r['n_gold'] for r in rows if r['leak'])/max(1,lk),
    sum(r['n_taken'] for r in rows if r['leak'])/max(1,lk),
    100*sum(r['n_gold'] for r in rows if r['leak'])/max(1,sum(r['n_taken'] for r in rows if r['leak']))))
ea = [r for r in rows if r["empty_agent"]]
print("records where agent made ZERO tool calls but trace shows the full gold list: %d (%.1f%%)" % (len(ea), 100*len(ea)/tot))
print("  of those, reward>0:", sum(1 for r in ea if (r['reward'] or 0) > 0))
gr = [r for r in rows if r["leak"] and r["gold_has_respond"]]
print("leaked records whose gold contains respond (=> extra user-sim LLM call at grading):", len(gr))
print()
by = collections.Counter((r["bench"], r["leak"]) for r in rows)
for k in sorted(by): print(" ", k, by[k])
print()
byl = collections.defaultdict(lambda: [0,0])
for r in rows:
    a = byl[r["agent"].split(" (")[0]]
    a[0] += 1; a[1] += r["leak"]
for k in sorted(byl): print("  %-45s %d/%d" % (k, byl[k][1], byl[k][0]))

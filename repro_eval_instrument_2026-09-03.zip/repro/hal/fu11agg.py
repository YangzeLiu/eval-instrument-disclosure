import csv, collections, statistics as st
WD="/PATH/TO/probes/hal"
R=list(csv.DictReader(open(WD+"/fu11_records.csv")))
for r in R:
    for k in ("n_gold_nt","leak","task","n_actions","n_write","n_read","n_respond","n_term","term_used","has_outputs"):
        r[k]=int(r[k])
    r["recorded"]=float(r["recorded"])
    r["offline"]=float(r["offline"]) if r["offline"]!="" else None
    r["graded"]=bool(r["leak"])
print("records",len(R),"| offline failures:",sum(1 for r in R if r["offline"] is None))
A=[r for r in R if r["n_gold_nt"]>=1]; B=[r for r in R if r["n_gold_nt"]==0]
print("Group A (detectable, gold has >=1 non-terminal action): %d ; Group B (gold terminate-only): %d"%(len(A),len(B)))
print("tasks with non-empty outputs:", sorted({r["task"] for r in R if r["has_outputs"]}))
print()
def agg(rows,label):
    print("== %s"%label)
    print("%-9s %-20s %5s %7s %7s %8s %9s %8s"%("scaffold","model","n","pub_acc","graded%","off_rate_ungr","corrected","delta"))
    out={}
    by=collections.defaultdict(list)
    for r in rows: by[(r["scaffold"],r["model"])].append(r)
    for k in sorted(by):
        s=by[k]; g=[r for r in s if r["graded"]]; u=[r for r in s if not r["graded"]]
        uu=[r for r in u if r["offline"] is not None]
        pub=sum(r["recorded"]>0 for r in s)/len(s)
        off=sum(r["offline"]>0 for r in uu)/len(uu) if uu else float("nan")
        corr=(sum(r["recorded"]>0 for r in g)+sum((r["offline"] or 0)>0 for r in u))/len(s)
        print("%-9s %-20s %5d %7.3f %7.1f %8.3f %9.3f %+8.3f"%(k[0],k[1],len(s),pub,100*len(g)/len(s),off,corr,corr-pub))
        out[k]=(pub,corr)
    return out
res=agg(A,"Group A, per (scaffold, model)")
print()
print("== Group A pooled per scaffold")
by=collections.defaultdict(list)
for r in A: by[r["scaffold"]].append(r)
for k in sorted(by):
    s=by[k]; g=[r for r in s if r["graded"]]; u=[r for r in s if not r["graded"]]
    uu=[r for r in u if r["offline"] is not None]
    pub=sum(r["recorded"]>0 for r in s)/len(s)
    corr=(sum(r["recorded"]>0 for r in g)+sum((r["offline"] or 0)>0 for r in u))/len(s)
    print("  %-9s n=%4d graded=%5.1f%%  published=%.3f  offline_rate_among_ungraded=%.3f  corrected=%.3f (%+.3f)"%(
        k,len(s),100*len(g)/len(s),pub,(sum(r["offline"]>0 for r in uu)/len(uu) if uu else float('nan')),corr,corr-pub))
print()
print("== agreement between offline replay and recorded reward, on GRADED records")
for k in sorted(by):
    g=[r for r in by[k] if r["graded"] and r["offline"] is not None]
    print("  %-9s n=%4d match=%.3f"%(k,len(g),sum((r["offline"]>0)==(r["recorded"]>0) for r in g)/len(g)))
print()
print("== ungraded episodes: write activity (Group A)")
for k in sorted(by):
    u=[r for r in by[k] if not r["graded"]]
    if not u: continue
    w=[r["n_write"] for r in u]
    print("  %-9s ungraded n=%4d  >=1 write: %5.1f%%  median writes=%.1f  mean writes=%.2f  median actions=%.0f"%(
        k,len(u),100*sum(1 for x in w if x>0)/len(u),st.median(w),sum(w)/len(w),st.median([r["n_actions"] for r in u])))
print()
print("== Group B (gold is terminate-only; nothing is injected, grading undetectable)")
by2=collections.defaultdict(list)
for r in B: by2[r["scaffold"]].append(r)
for k in sorted(by2):
    s=by2[k]
    print("  %-9s n=%4d published=%.3f offline=%.3f  term_used=%.1f%%"%(
        k,len(s),sum(r["recorded"]>0 for r in s)/len(s),
        sum((r["offline"] or 0)>0 for r in s)/len(s),100*sum(r["term_used"] for r in s)/len(s)))
print()
print("== scaffold ordering per model (Group A corrected vs published)")
mods=sorted({m for (s,m) in res})
print("%-20s %-28s %s"%("model","published order","corrected order"))
for mo in mods:
    ks=[(s,res[(s,mo)]) for s in ("GEN","FEWSHOT","TOOLCALL") if (s,mo) in res]
    if len(ks)<2: continue
    po=" > ".join("%s(%.2f)"%(s,v[0]) for s,v in sorted(ks,key=lambda x:-x[1][0]))
    co=" > ".join("%s(%.2f)"%(s,v[1]) for s,v in sorted(ks,key=lambda x:-x[1][1]))
    print("%-20s %-28s %s"%(mo,po,co))

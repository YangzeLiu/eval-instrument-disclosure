import os, sys, json, re, glob, collections, traceback
from halio import load, WD

# ---------------- pricing (USD per 1M tokens) ----------------
PRICE = {
 'claude-opus-4-1':(15,75),'claude-opus-4.1':(15,75),'claude-opus-4':(15,75),
 'claude-3-7-sonnet':(3,15),'claude-3.7-sonnet':(3,15),
 'claude-sonnet-4-5':(3,15),'claude-sonnet-4.5':(3,15),'claude-sonnet-4':(3,15),
 'claude-haiku-4-5':(1,5),'claude-haiku-4.5':(1,5),
 'deepseek-r1':(0.55,2.19),'deepseek-reasoner':(0.55,2.19),
 'deepseek-v3':(1.25,1.25),'deepseek-chat':(1.25,1.25),
 'gpt-4.1':(2,8),'gpt-4o':(2.5,10),'gpt-5':(1.25,10),
 'gemini-2.0-flash':(0.1,0.4),'gemini-2.5-pro':(1.25,10),
 'o3-mini':(1.1,4.4),'o4-mini':(1.1,4.4),'o3':(2,8),
}
def price(m):
    if not m: return (0,0)
    s=str(m).lower().split('/')[-1]
    best=None
    for k,v in PRICE.items():
        if s.startswith(k) and (best is None or len(k)>len(best[0])): best=(k,v)
    if best: return best[1]
    for k,v in PRICE.items():
        if k in s and (best is None or len(k)>len(best[0])): best=(k,v)
    return best[1] if best else (0,0)

# ---------------- error signatures ----------------
def signature(text):
    if not text: return 'none'
    t = text[:20000]
    m = re.search(r'"type":\s*"(\w+)"', t); et = m.group(1) if m else ''
    if re.search(r'usage polic|content_policy|content filter|flagged as potentially violating|invalid_prompt', t, re.I): return 'provider_content_filter'
    if re.search(r'RateLimitError|rate_limit_error|overloaded_error|\b429\b|quota|too many requests', t, re.I): return 'rate_limit'
    if re.search(r'Timeout|timed out|deadline exceeded', t, re.I): return 'timeout'
    if re.search(r'context.?length|context_length_exceeded|prompt is too long|maximum context|too many tokens', t, re.I): return 'context_len'
    if re.search(r'\b50[023]\b|Bad Gateway|InternalServerError|APIConnectionError|ServiceUnavailable|ConnectionError|Provider returned error', t, re.I): return 'provider_5xx'
    if et in ('BadRequestError','AuthenticationError','NotFoundError','PermissionDeniedError','UnsupportedParamsError','APIError'): return 'bad_request'
    if et in ('AttributeError','TypeError','KeyError','IndexError','NameError','UnboundLocalError','RecursionError','AssertionError'): return 'scaffold_crash'
    if re.search(r'Expecting value: line 1 column 1', t): return 'answer_parse_fail'
    if re.search(r'JSONDecodeError|Invalid JSON|ValidationError|pydantic', t, re.I): return 'parse_error'
    if re.search(r'max.?steps|maximum number of steps|max.?turns|step limit|iteration limit|budget exceeded|out of budget', t, re.I): return 'max_steps'
    if re.search(r"I can(?:no|\')t (?:assist|help|comply)|I must decline|against my guidelines", t): return 'refusal'
    return 'other_error'

# ---------------- per-benchmark success ----------------
def task_success(d):
    """returns dict task_id -> (success01, score_float, extra_err_text)"""
    res=d.get('results') or {}; er=d.get('raw_eval_results')
    out={}
    bench=(d.get('config') or {}).get('benchmark_name','')
    if isinstance(er,dict) and 'eval_result' in er and isinstance(er['eval_result'],dict):
        for t,v in er['eval_result'].items():
            if isinstance(v,dict):
                s=v.get('success_rate', v.get('success', 0))
                li=v.get('log_info','')
                out[str(t)]=(int(bool(s)), float(s) if isinstance(s,(int,float)) else 0.0,
                             li if isinstance(li,str) else json.dumps(li)[:2000])
    elif isinstance(er,dict) and er and all(isinstance(v,dict) for v in er.values()):
        for t,v in er.items():
            if 'reward' in v:
                out[str(t)]=(int(v['reward']>=0.999), float(v['reward']), '')
            elif 'correct_written_answers' in v:
                tw=v.get('total_written_questions',0) or 0; tv=v.get('total_vision_questions',0) or 0
                cw=v.get('correct_written_answers',0) or 0; cv=v.get('correct_vision_answers',0) or 0
                tot=tw+tv; cor=cw+cv
                out[str(t)]=(int(tot>0 and cor==tot), (cor/tot if tot else 0.0), str(v.get('error') or '')[:2000])
    # fall back / override with explicit task lists
    st=res.get('successful_tasks') or []; ft=res.get('failed_tasks') or []
    if st or ft:
        for t in st: out.setdefault(str(t),(1,1.0,''))
        for t in ft: out.setdefault(str(t),(0,0.0,''))
        stset={str(t) for t in st}
        if st and ft:
            for t in list(out):
                if t in stset: out[t]=(1,out[t][1] if out[t][1] else 1.0,out[t][2])
    return out

def scaffold_of(cfg, fname):
    rc = cfg.get('run_command','') or ''
    m = re.search(r'--agent_dir\s+(?:agents/)?([\w\-./]+)', rc)
    if m: return m.group(1).strip('/').split('/')[-1]
    an=(cfg.get('agent_name') or '').lower()
    for pat,name in [('fewshot','taubench_few_shot'),('few shot','taubench_few_shot'),
                     ('tool calling','taubench_tool_calling'),('toolcalling','taubench_tool_calling'),
                     ('generalist','hal_generalist_agent'),('self-debug','sab_example_agent'),
                     ('claude code','claude_code_agent'),('core-agent','core_agent'),
                     ('swe-agent','sweagent'),('sweagent','sweagent'),
                     ('zero shot','scicode_zero_shot_agent'),('zero-shot','scicode_zero_shot_agent'),
                     ('scicode tool','scicode_tool_calling_agent')]:
        if pat in an: return name
    fn=fname.lower()
    for pat,name in [('_sweagent','sweagent'),('_my_agent','my_agent'),
                     ('_hal_generalist','hal_generalist_agent'),
                     ('scicode_tool_calling','scicode_tool_calling_agent'),
                     ('scicode-tool_calling','scicode_tool_calling_agent'),
                     ('scicode_zero_shot','scicode_zero_shot_agent')]:
        if pat in fn: return name
    return 'unknown:'+fname[:40]

def reasoning_of(cfg):
    a=cfg.get('agent_args') or {}
    for k in ('reasoning_effort','reasoning','thinking'):
        if k in a: return str(a[k])
    rc=cfg.get('run_command','') or ''
    m=re.search(r'reasoning_effort=(\w+)', rc)
    return m.group(1) if m else 'default'

def parse_file(p):
    fname=os.path.basename(p)
    d=load(p)
    cfg=d.get('config') or {}; res=d.get('results') or {}
    bench=cfg.get('benchmark_name') or fname.split('_UPLOAD')[0]
    agent=cfg.get('agent_name','?'); run_id=cfg.get('run_id', fname.split('_UPLOAD')[0])
    scaf=scaffold_of(cfg,fname)
    args=cfg.get('agent_args') or {}
    model=args.get('model_name') or (res.get('model_name') if isinstance(res.get('model_name'),str) else None) or '?'
    reff=reasoning_of(cfg)
    date=cfg.get('date','')
    succ=task_success(d)
    lat=res.get('latencies') or {}
    L=d.get('raw_logging_results') or []
    op=lambda x: x['op_name'].split('/op/')[-1].split(':')[0] if x.get('op_name') else '?'
    ids={x['id'] for x in L}
    # dedup: skip a call whose parent is also an llm call present in the log
    agent_key = str(model).lower().split('/')[-1]
    per=collections.defaultdict(lambda: dict(n_calls=0,n_calls_dup=0,pt=0,ct=0,cr=0,cc=0,
        upt=0,uct=0,n_tool=0,n_exc=0,n_err=0,lat_ms=0,exc_txt=[],last_txt='',finish=collections.Counter(),
        models=collections.Counter(), t0=None, t1=None))
    for x in L:
        tid=str((x.get('attributes') or {}).get('weave_task_id'))
        r=per[tid]
        parent_is_llm = x.get('parent_id') in ids
        if parent_is_llm:
            r['n_calls_dup']+=1
            continue
        r['n_calls']+=1
        sm=x.get('summary') or {}
        wv=sm.get('weave') or {}
        r['lat_ms']+=wv.get('latency_ms') or 0
        if wv.get('status')=='error': r['n_err']+=1
        ex=x.get('exception')
        if ex:
            r['n_exc']+=1
            if len(r['exc_txt'])<5: r['exc_txt'].append(str(ex)[:1500])
        mname=(x.get('inputs') or {}).get('model')
        r['models'][str(mname)]+=1
        for m,v in (sm.get('usage') or {}).items():
            is_agent = agent_key and agent_key in str(m).lower()
            pt=v.get('prompt_tokens',0) or 0; ct=v.get('completion_tokens',0) or 0
            if is_agent:
                r['pt']+=pt; r['ct']+=ct
                r['cr']+=v.get('cache_read_input_tokens',0) or 0
                r['cc']+=v.get('cache_creation_input_tokens',0) or 0
            else:
                r['upt']+=pt; r['uct']+=ct
        o=x.get('output')
        if isinstance(o,dict):
            for ch in (o.get('choices') or []):
                r['finish'][ch.get('finish_reason')]+=1
                msg=ch.get('message') or {}
                tc=msg.get('tool_calls')
                if tc: r['n_tool']+=len(tc)
                c=msg.get('content')
                if isinstance(c,str) and c.strip(): r['last_txt']=c[-1500:]
        sa=x.get('started_at'); ea=x.get('ended_at')
        if sa and (r['t0'] is None or sa<r['t0']): r['t0']=sa
        if ea and (r['t1'] is None or ea>r['t1']): r['t1']=ea
    has_logs = len(L)>0
    pin,pout=price(model)
    rows=[]
    tasks=set(succ)|set(lat)|set(per)
    tasks.discard('None')
    for t in sorted(tasks):
        s=succ.get(t,(None,None,''))
        r=per.get(t)
        lt=lat.get(t) or {}
        exc=' || '.join(r['exc_txt']) if r else ''
        nexc=(r['n_exc'] if r else 0); nerr=(r['n_err'] if r else 0)
        if not has_logs:
            sig='no_logs'
        elif nexc or nerr:
            sig=signature(exc) if exc.strip() else 'provider_5xx'
        elif s[0]==1:
            sig='none'
        elif r and r['finish'].get('length'):
            sig='output_truncated'
        elif (s[2] or '').strip():
            sig=signature(s[2])
            if sig=='other_error': sig='clean_wrong'
        elif r is None or r['n_calls']==0:
            sig='no_llm_calls'
        else:
            sig='clean_wrong'
        rows.append(dict(
            benchmark=bench, has_logs=has_logs, scaffold=scaf, agent_name=agent, model=model, reasoning=reff,
            run_id=run_id, date=date, file=fname, task_id=t,
            success=s[0], score=s[1],
            n_llm_calls=(r['n_calls'] if r else 0), n_llm_calls_nested=(r['n_calls_dup'] if r else 0),
            prompt_tokens=(r['pt'] if r else 0), completion_tokens=(r['ct'] if r else 0),
            cache_read_tokens=(r['cr'] if r else 0), cache_creation_tokens=(r['cc'] if r else 0),
            other_prompt_tokens=(r['upt'] if r else 0), other_completion_tokens=(r['uct'] if r else 0),
            n_tool_calls=(r['n_tool'] if r else 0), n_exceptions=(r['n_exc'] if r else 0),
            n_error_status=(r['n_err'] if r else 0),
            sum_latency_ms=(r['lat_ms'] if r else 0),
            wall_seconds=lt.get('total_time'),
            first_call=lt.get('first_call_timestamp') or (r['t0'] if r else None),
            last_call=lt.get('last_call_timestamp') or (r['t1'] if r else None),
            n_models_used=(len(r['models']) if r else 0),
            finish_stop=(r['finish'].get('stop',0) if r else 0),
            finish_length=(r['finish'].get('length',0) if r else 0),
            finish_toolcalls=(r['finish'].get('tool_calls',0) if r else 0),
            err_sig=sig,
            err_head=(exc[:300] if exc else ((s[2] or '')[:300])),
            final_answer=((r['last_txt'] or '')[-200:] if r else ''),
            cost_usd=((r['pt']*pin + r['ct']*pout)/1e6 if r else 0.0),
        ))
    meta=dict(file=fname, benchmark=bench, scaffold=scaf, agent_name=agent, model=model,
              reasoning=reff, run_id=run_id, date=date,
              hal_total_cost=d.get('total_cost'),
              hal_total_usage=d.get('total_usage'),
              hal_headline={k:v for k,v in res.items() if isinstance(v,(int,float))},
              n_tasks=len(rows), n_calls_total=len(L),
              n_calls_nested=sum(1 for x in L if x.get('parent_id') in ids))
    return rows, meta

def _safe(p):
    try:
        r,m=parse_file(p); return r,m,None
    except Exception as e:
        import traceback; traceback.print_exc()
        return [],None,f"{os.path.basename(p)}: {e}"

if __name__=='__main__':
    files=sorted(glob.glob(f"{WD}/raw/*.zip"))
    if len(sys.argv)>1: files=[f for f in files if re.search(sys.argv[1], os.path.basename(f))]
    import multiprocessing as mp
    def _w(p):
        try:
            r,m=parse_file(p); return r,m,None
        except Exception as e:
            return [],None,f"{os.path.basename(p)}: {e}"
    allrows=[]; metas=[]
    with mp.Pool(12) as pool:
        for i,(r,m,err) in enumerate(pool.imap_unordered(_safe, files)):
            if err: print(f"[{i+1}/{len(files)}] ERROR {err}", flush=True); continue
            allrows+=r; metas.append(m)
            print(f"[{i+1}/{len(files)}] {m['file'][:70]} tasks={len(r)}", flush=True)
    import pandas as pd
    df=pd.DataFrame(allrows); df.to_parquet(f"{WD}/runs.parquet")
    json.dump(metas, open(f"{WD}/run_meta.json","w"), indent=1, default=str)
    print("ROWS", len(df), "RUNS", len(metas))

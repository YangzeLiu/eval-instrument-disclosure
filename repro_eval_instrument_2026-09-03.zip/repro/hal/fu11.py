import sys, types, glob, os, json, collections, csv
import multiprocessing as mp
class _F:
    def __getattr__(self,k): return _F()
    def __getitem__(self,k): return _F()
    def __iter__(self): return iter([_F()])
    def __call__(self,*a,**k): return {"role":"user","content":""}
    def __str__(self): return ""
    def __float__(self): return 0.0
m=types.ModuleType("litellm"); m.completion=lambda *a,**k:_F(); sys.modules["litellm"]=m
WD="/PATH/TO/probes/hal"
TB=WD+"/taubench/tau-bench-14bf0ef52e595922d597a38f32d3e8c0dce3a8f8"
sys.path.insert(0,TB); sys.path.insert(0,WD+"/scripts")
from tau_bench.envs.airline import MockAirlineDomainEnv
from tau_bench.envs import user as _u
_u.LLMUserSimulationEnv.generate_next_message=lambda self,msgs:""
_u.LLMUserSimulationEnv.get_total_cost=lambda self:0.0
_u.LLMUserSimulationEnv.step=lambda self,c:""
from tau_bench.types import Action
from halio import load
TERM={"transfer_to_human_agents"}
WRITE={"book_reservation","cancel_reservation","send_certificate",
       "update_reservation_baggages","update_reservation_flights","update_reservation_passengers"}
READONLY_NONTOOL={"respond","think"}
CANON=[('claude-opus-4-1','claude-opus-4.1'),('claude-opus-4.1','claude-opus-4.1'),
 ('claude-opus-4','claude-opus-4'),('claude-3-7-sonnet','claude-3.7-sonnet'),
 ('claude-3.7-sonnet','claude-3.7-sonnet'),('claude-sonnet-4-5','claude-sonnet-4.5'),
 ('claude-sonnet-4','claude-sonnet-4'),('claude-haiku-4-5','claude-haiku-4.5'),
 ('deepseek-r1','deepseek-r1'),('deepseek-reasoner','deepseek-r1'),('r1','deepseek-r1'),
 ('deepseek-v3','deepseek-v3'),('deepseek-chat','deepseek-v3'),
 ('gpt-4.1','gpt-4.1'),('gpt-4o','gpt-4o'),('gpt-5','gpt-5'),
 ('gemini-2.0-flash','gemini-2.0-flash'),('gemini-2.5-pro','gemini-2.5-pro'),
 ('o4-mini','o4-mini'),('o3-mini','o3-mini'),('o3','o3')]
def canon(x):
    z=str(x).lower().split('/')[-1]; best=None
    for k,v in CANON:
        if z.startswith(k) and (best is None or len(k)>best[0]): best=(len(k),v)
    return best[1] if best else z

def env(i):
    e=MockAirlineDomainEnv(user_strategy="llm",user_model="gpt-4o",user_provider="openai",
                           task_split="test",task_index=i)
    e.reset(task_index=i); return e

def score(i,actions):
    e=env(i)
    for a in actions:
        nm=a.get("name")
        if nm=="respond" or nm in TERM:
            e.actions.append(Action(name=nm,kwargs=a.get("kwargs") or {})); continue
        try: e.step(Action(name=nm,kwargs=a.get("kwargs") or {}))
        except Exception: pass
    return e.calculate_reward().reward

def one(z):
    try: d=load(z)
    except Exception: return []
    cfg=d.get("config") or {}
    an=cfg.get("agent_name") or ""
    sc="GEN" if "Generalist" in an else ("FEWSHOT" if "hot" in an.lower() else "TOOLCALL")
    mo=canon((cfg.get("agent_args") or {}).get("model_name") or an)
    rer=d.get("raw_eval_results") or {}
    if not isinstance(rer,dict): return []
    rows=[]
    for tid,v in rer.items():
        if not isinstance(v,dict): continue
        t=v.get("task"); ta=v.get("taken_actions")
        if not isinstance(t,dict) or not isinstance(ta,list): continue
        gold=[(x.get("name"),x.get("kwargs")) for x in (t.get("actions") or []) if x.get("name") not in TERM]
        got=[x for x in ta if isinstance(x,dict)]
        gk=[(x.get("name"),x.get("kwargs")) for x in got]
        n=len(gold)
        leak = n>=1 and len(gk)>=n and gk[-n:]==gold
        own = got[:-n] if leak else got
        names=[x.get("name") for x in own]
        term_used=any(x in TERM for x in names)
        try: off=score(int(tid),own)
        except Exception: off=None
        outs=list(t.get("outputs") or [])
        rows.append(dict(zipf=os.path.basename(z),scaffold=sc,model=mo,task=int(tid),
            n_gold_nt=n, leak=int(leak), recorded=float(v.get("reward") or 0),
            offline=(float(off) if off is not None else ""),
            n_actions=len(own),
            n_write=sum(1 for x in names if x in WRITE),
            n_read=sum(1 for x in names if x not in WRITE and x not in TERM and x not in READONLY_NONTOOL),
            n_respond=sum(1 for x in names if x=="respond"),
            n_term=sum(1 for x in names if x in TERM),
            term_used=int(term_used), has_outputs=int(len(outs)>0)))
    return rows

if __name__=="__main__":
    zs=sorted(glob.glob(WD+"/raw/*taubench_airline*.zip"))
    with mp.Pool(8) as p:
        res=p.map(one,zs)
    rows=[r for x in res for r in x]
    with open(WD+"/fu11_records.csv","w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print("records",len(rows),"runs",len({r['zipf'] for r in rows}))

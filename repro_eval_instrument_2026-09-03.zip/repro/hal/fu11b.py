import sys, types, csv, collections
m=types.ModuleType("litellm"); m.completion=lambda *a,**k:None; sys.modules["litellm"]=m
WD="/PATH/TO/probes/hal"
sys.path.insert(0,WD+"/taubench/tau-bench-14bf0ef52e595922d597a38f32d3e8c0dce3a8f8")
from tau_bench.envs.airline.tasks_test import TASKS
WRITE={"book_reservation","cancel_reservation","send_certificate",
       "update_reservation_baggages","update_reservation_flights","update_reservation_passengers"}
gw={i:sum(1 for a in t.actions if a.name in WRITE) for i,t in enumerate(TASKS)}
print("airline tasks whose gold contains >=1 write action: %d / 50"%sum(1 for v in gw.values() if v))
R=list(csv.DictReader(open(WD+"/fu11_records.csv")))
for r in R:
    for k in ("n_gold_nt","leak","task","n_write","n_actions"): r[k]=int(r[k])
    r["recorded"]=float(r["recorded"]); r["offline"]=float(r["offline"]) if r["offline"]!="" else None
    r["gold_write"]=gw[r["task"]]
A=[r for r in R if r["n_gold_nt"]>=1]
print()
print("Group A split by whether GOLD requires a write:")
for gwflag in (1,0):
    s=[r for r in A if (r["gold_write"]>0)==bool(gwflag)]
    print("  gold_write=%s  n=%d"%(bool(gwflag),len(s)))
    for sc in ("GEN","FEWSHOT","TOOLCALL"):
        t=[r for r in s if r["scaffold"]==sc]
        if not t: continue
        g=[r for r in t if r["leak"]]; u=[r for r in t if not r["leak"]]
        pub=sum(r["recorded"]>0 for r in t)/len(t)
        corr=(sum(r["recorded"]>0 for r in g)+sum((r["offline"] or 0)>0 for r in u))/len(t)
        print("    %-9s n=%4d graded=%5.1f%% published=%.3f corrected=%.3f (%+.3f)"%(sc,len(t),100*len(g)/len(t),pub,corr,corr-pub))
print()
u=[r for r in A if r["scaffold"]=="GEN" and not r["leak"]]
p=[r for r in u if (r["offline"] or 0)>0]
print("ungraded GEN (Group A): n=%d ; offline pass n=%d (%.1f%%)"%(len(u),len(p),100*len(p)/len(u)))
print("  of those passes: gold requires a write in %d (%.1f%%) ; agent made >=1 write in %d (%.1f%%)"%(
    sum(1 for r in p if r["gold_write"]>0),100*sum(1 for r in p if r["gold_write"]>0)/len(p),
    sum(1 for r in p if r["n_write"]>0),100*sum(1 for r in p if r["n_write"]>0)/len(p)))
print("  passes where gold needs a write AND agent wrote: %d"%sum(1 for r in p if r["gold_write"]>0 and r["n_write"]>0))
print("  ungraded GEN on write-gold tasks: n=%d, offline pass %.3f"%(
    len([r for r in u if r["gold_write"]>0]), sum(1 for r in u if r["gold_write"]>0 and (r["offline"] or 0)>0)/max(1,len([r for r in u if r["gold_write"]>0]))))

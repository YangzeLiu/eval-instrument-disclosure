# Reproduction scripts

These scripts re-derive every number in `../TECHNOTE.md` from public artifacts. No agent is run and no LLM is called. All paths are placeholders: replace `/PATH/TO/probes/hal` and `/PATH/TO/probes/tau2` with your working directories (or export `HAL_PROBE_DIR`).

## Inputs

| artifact | location | version used |
|---|---|---|
| HAL trace archives | `https://huggingface.co/datasets/agent-evals/hal_traces` (380 zips) | snapshot of 2026-09-02 |
| HAL decryption passphrase | constant in `https://hal.cs.princeton.edu/static/downloads/hal-decrypt.sh` | export as `HAL_DECRYPT_PASSPHRASE` |
| HAL leaderboard pages | `https://hal.cs.princeton.edu/<benchmark>` | fetched 2026-09-02 |
| tau-bench | `github.com/sierra-research/tau-bench` commit `14bf0ef52e595922d597a38f32d3e8c0dce3a8f8` (upstream; the commit `hal/benchmarks/taubench/taubench_setup.sh` pins). HAL's agents themselves were installed from the fork `benediktstroebl/tau-bench@807e348` (`pyproject.toml`, `agents/hal_generalist_agent/requirements.txt`), whose airline gold differs from upstream on tasks 2, 10 and 23. `fu11.py` grades against this upstream checkout and, in a second column, against the gold embedded in each record, which matches the fork; the embedded-gold column is the fork-equivalent control for those three tasks. | unpack to `/PATH/TO/probes/hal/taubench/tau-bench-14bf0ef52e595922d597a38f32d3e8c0dce3a8f8` |
| τ²-bench source | `github.com/sierra-research/tau2-bench` tags `v0.2.0`, `v1.0.0`, `v1.0.1`, plus the commit immediately before `v1.0.1` | unpack to `src_v0.2.0/tau2-bench-0.2.0`, `src_v1.0.0/tau2-bench-1.0.0`, `src_pre-v1.0.1/tau2-bench-pre-v1.0.1`, `src_v1.0.1/tau2-bench-1.0.1` |
| τ²-bench leaderboard trajectories | `https://sierra-tau-bench-public.s3.amazonaws.com/` (public listing) | banking files, 30 to 95 MB each |
| τ²-bench repository trajectories | `data/tau2/...` inside the tagged source trees | 26 files |

Python 3.10+, `cryptography`, `pandas`. τ²-bench venvs are built by `tau2/mkvenv.sh`.

## HAL

```bash
export HAL_PROBE_DIR=/PATH/TO/probes/hal
export HAL_DECRYPT_PASSPHRASE=...      # from hal-decrypt.sh
cd $HAL_PROBE_DIR && mkdir -p raw pages

python3 recon.py                       # scrape the 9 leaderboards -> recon_leaderboard.json
# files.json = the HF API listing of agent-evals/hal_traces (curl the datasets API or hf-mirror)
python3 mklist.py                      # split scicode/swebench archives into 4 download lists
bash download.sh dl_sci0.txt           # repeat per list; edit MIRROR if not in mainland China

python3 parse.py                       # per-run summary, error signatures, run_meta.json
python3 dupcost.py                     # Finding 1: token ratio all-calls vs root-only -> dupcost.csv
python3 goldleak.py                    # Finding 3: gold suffix detection -> gold_leak.csv
python3 replay_all.py                  # Finding 3: verbatim vs stripped replay agreement
python3 fu11.py && python3 fu11agg.py  # Finding 2: offline re-grade -> fu11_records.csv, corrected table
python3 fu11b.py                       # Finding 2: strict write-gold subset
python3 fu12.py                        # action recounts with gold stripped
```

`halio.py` is the shared loader (decrypt one archive in memory). `fu11.py`, `fu12.py`, `replay_all.py` stub `litellm` and the user simulator, so the pinned tau-bench runs without network.

## τ²-bench

```bash
cd /PATH/TO/probes/tau2
bash fetch.sh                          # clone tau2-bench (then unpack the four source trees as listed above)
bash mkvenv.sh                         # one venv per release; then create venv_common with the 1.0.1 deps
bash s3list.sh                         # list the public S3 bucket -> s3keys.txt, s3sizes.txt
# build s3_traj_index.json as [{"key":..., "size":...}] from those two files
bash dl.sh                             # download banking trajectory files -> trajs/

python3 runmatrix.py --glob 'trajs/*banking*.json' --outdir scores_bank --workers 8 \
  --retrieval-variant bm25_grep \
  --conds codePRE,code101,code101fresh,code101_noenvkw,code101_strict,codePRE_data101,code101_dataPRE,code101fresh_dataPRE
python3 runmatrix.py --glob 'src_v0.2.0/tau2-bench-0.2.0/data/tau2/**/*.json' --outdir scores_arts --workers 8 \
  --conds code020,code100,codePRE,code101,code101fresh,code100fresh
python3 final_analysis.py              # -> transitions.json and printed tables
python3 detail.py                      # flip concentration per task
python3 subdiff.py                     # official 17-submission diff (needs submission_diffs.json built from
                                       #   web/leaderboard/public/submissions/*/submission.json at pre-v1.0.1 and v1.0.1)
```

`rescore.py` grades one results file under one condition. Flags: `--fresh-tasks` swaps in the current `tasks.json`; `--no-env-kwargs` drops the 1.0.1 `read_log_allowlist`; `--no-strict-replay-off` restores strict replay. Conditions are named in `runmatrix.py`.

Reference outputs included here: `tau2/transitions_bank.json` (banking transition matrices) and `tau2/official_leaderboard_delta.json` (17-submission diff).

## Notes

- `s3list.sh` contains the string `continuation-token=`; it is the S3 ListObjectsV2 pagination parameter, not a credential.
- Banking `alltools` retrieval needs an OpenAI embedding key; we used `bm25_grep` and validated against the official 24.74.
- 4 of 388 banking and 160 of 456 retail-with-fresh-tasks simulations need an LLM judge and are recorded as unscorable.

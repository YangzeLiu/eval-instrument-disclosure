#!/bin/bash
cd /PATH/TO/probes/tau2/
mkdir -p trajs
python3 - <<"PY"
import json, urllib.parse, urllib.request, os, sys, subprocess
idx=json.load(open("s3_traj_index.json"))
B="https://sierra-tau-bench-public.s3.amazonaws.com/"
sel=[x for x in idx if "banking" in x["key"].lower() and "/artifacts/" not in x["key"] and x["key"].endswith(".json")]
sel.sort(key=lambda z:z["size"])
for x in sel:
    sub=x["key"].split("/")[1]
    fn=os.path.basename(x["key"])
    out=f"trajs/{sub}__{fn}"
    if os.path.exists(out) and os.path.getsize(out)==x["size"]:
        print("skip",out); continue
    url=B+urllib.parse.quote(x["key"])
    print("get",out,round(x["size"]/1e6,1),"MB",flush=True)
    r=subprocess.run(["curl","-sS","--max-time","1800","-o",out,url])
    print("  rc",r.returncode, os.path.getsize(out) if os.path.exists(out) else -1, flush=True)
PY
echo DLDONE

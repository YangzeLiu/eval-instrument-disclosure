#!/bin/bash
cd /PATH/TO/probes/tau2/
B=https://sierra-tau-bench-public.s3.amazonaws.com
tok=""
> s3keys.txt
for i in $(seq 1 200); do
  if [ -z "$tok" ]; then u="$B/?list-type=2&max-keys=1000"; else u="$B/?list-type=2&max-keys=1000&continuation-token=$(python3 -c "import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1],safe=\"\"))" "$tok")"; fi
  curl -sS --max-time 120 "$u" > _p.xml || break
  grep -o "<Key>[^<]*</Key>" _p.xml | sed "s/<Key>//;s/<\/Key>//" >> s3keys.txt
  grep -o "<Size>[0-9]*</Size>" _p.xml | sed "s/<Size>//;s/<\/Size>//" >> s3sizes.txt
  if grep -q "<IsTruncated>true</IsTruncated>" _p.xml; then
    tok=$(grep -o "<NextContinuationToken>[^<]*</NextContinuationToken>" _p.xml | sed "s/<NextContinuationToken>//;s/<\/NextContinuationToken>//")
  else break; fi
done
wc -l s3keys.txt

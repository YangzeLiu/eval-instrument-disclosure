import json, glob, os, collections
ROOT = "/PATH/TO/probes/tau2"
d = json.load(open(ROOT + "/transitions.json"))

print("== BANKING codePRE -> code101 (flip concentration) ==")
b = d["scores_bank"]["pairs"]["code101->codePRE"]  # A=code101 B=codePRE ; pf means pass@101 -> fail@PRE
alltasks = collections.Counter()
for stem, r in b["per_file"].items():
    print("  %-46s pf(=fail->pass fwd)=%d n_flip_tasks=%d delta_fwd=%+.2fpp n_common=%d" %
          (stem[:46], r["matrix"]["pf"], r["n_flip_tasks"], -r["paired_delta_pp"], r["n_common"]))
    for t, c in r["flip_tasks"].items():
        alltasks[t] += c
print("  distinct banking tasks flipped:", len(alltasks))
print("  top:", alltasks.most_common(15))

print("\n== BANKING code101 -> code101_noenvkw (read_log_allowlist effect) ==")
b = d["scores_bank"]["pairs"]["code101->code101_noenvkw"]
at = collections.Counter()
for stem, r in b["per_file"].items():
    for t, c in r["flip_tasks"].items():
        at[t] += c
print("  distinct tasks:", len(at), at.most_common(15))

print("\n== BANKING code101_noenvkw -> codePRE (tool-code effect alone) ==")
b = d["scores_bank"]["pairs"]["code101_noenvkw->codePRE"]
at = collections.Counter()
for stem, r in b["per_file"].items():
    for t, c in r["flip_tasks"].items():
        at[t] += c
print("  distinct tasks:", len(at), at.most_common(20))

print("\n== ARTS code101 -> code101fresh (task-definition edits) ==")
b = d["scores_arts"]["pairs"]["code101->code101fresh"]
at = collections.Counter()
for stem, r in b["per_file"].items():
    if r["n_flip_tasks"]:
        print("  %-52s pf=%d fp=%d n_flip_tasks=%d delta=%+.2fpp n_common=%d unsc_fresh=%d" %
              (stem[:52], r["matrix"]["pf"], r["matrix"]["fp"], r["n_flip_tasks"],
               r["paired_delta_pp"], r["n_common"], r["unscorable_B"]))
        for t, c in r["flip_tasks"].items():
            at[t] += c
print("  distinct arts tasks flipped:", len(at))
print("  ", at.most_common(30))

print("\n== unscorable error signatures ==")
for od in ("scores_bank", "scores_arts"):
    sig = collections.Counter()
    for f in glob.glob(ROOT + "/" + od + "/*.json"):
        cond = os.path.basename(f)[:-5].rsplit("__", 1)[1]
        try:
            j = json.load(open(f))
        except Exception:
            continue
        for r in j["records"]:
            if r["status"] != "ok":
                sig[(cond, (r.get("error") or "")[:70])] += 1
    print(" ", od)
    for k, v in sig.most_common(14):
        print("    %-22s %-72s %d" % (k[0], k[1], v))

"""Version-adaptive re-scorer for tau2 trajectory files.

Run with PYTHONPATH=<version src> and TAU2_DATA_DIR=<version data>.
Emits compact per-simulation rewards; isolates per-simulation exceptions
so unscorable != fail.
"""
import argparse, inspect, json, os, sys, time, traceback

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--fresh-tasks", action="store_true")
    ap.add_argument("--no-env-kwargs", action="store_true",
                    help="1.0.1 only: suppress the read_log_allowlist env kwarg")
    ap.add_argument("--no-strict-replay-off", action="store_true",
                    help="1.0.1 only: do NOT pass strict_replay=False")
    ap.add_argument("--label", default="")
    ap.add_argument("--retrieval-variant", default=None)
    a = ap.parse_args()

    os.environ.setdefault("LOGURU_LEVEL", "ERROR")
    from loguru import logger
    logger.remove()
    logger.add(sys.stderr, level="ERROR")

    from tau2.data_model.simulation import Results
    from tau2.evaluator.evaluator import EvaluationType, evaluate_simulation
    import tau2
    try:
        from tau2.scripts.evaluate_trajectories import is_solo_mode, get_communication_mode
    except Exception:
        from tau2.scripts.evaluate_trajectories import is_solo_mode
        get_communication_mode = None

    t0 = time.time()
    results = Results.load(a.results)
    load_s = time.time() - t0

    domain = results.info.environment_info.domain_name
    fresh_report = {"applied": False, "n_replaced": 0, "n_missing": 0, "missing": []}
    if a.fresh_tasks:
        from tau2.registry import registry
        fresh = {t.id: t for t in registry.get_tasks_loader(domain)(None)}
        missing = [t.id for t in results.tasks if t.id not in fresh]
        changed = sum(1 for t in results.tasks
                      if t.id in fresh and fresh[t.id].model_dump() != t.model_dump())
        results.tasks = [fresh.get(t.id, t) for t in results.tasks]
        fresh_report = {"applied": True, "n_replaced": len(results.tasks) - len(missing),
                        "n_changed": changed, "n_missing": len(missing), "missing": missing}

    solo_mode = is_solo_mode(results)
    tasks = {t.id: t for t in results.tasks}

    sig = set(inspect.signature(evaluate_simulation).parameters)
    supports_mode = "mode" in sig
    supports_env_kwargs = "env_kwargs" in sig
    supports_strict = "strict_replay" in sig

    allow_fn = None
    if supports_env_kwargs and not a.no_env_kwargs and domain == "banking_knowledge":
        try:
            from tau2.runner.build import _derive_read_log_allowlist
            allow_fn = _derive_read_log_allowlist
        except Exception:
            allow_fn = None

    def build_env_kwargs(task):
        ek = {}
        if domain == "banking_knowledge" and a.retrieval_variant:
            ek["retrieval_variant"] = a.retrieval_variant
        if allow_fn is not None:
            ek["read_log_allowlist"] = allow_fn(task)
        return ek or None

    recs = []
    n_err = 0
    trial_counter = {}
    for sim in results.simulations:
        tid = sim.task_id
        trial = getattr(sim, "trial", None)
        if trial is None:
            trial = trial_counter.get(tid, 0)
        trial_counter[tid] = trial_counter.get(tid, 0) + 1
        task = tasks.get(tid)
        rec = {"task_id": tid, "trial": trial, "sim_id": getattr(sim, "id", None),
               "orig_reward": None, "reward": None, "status": "ok",
               "term": str(getattr(sim, "termination_reason", None))}
        ri = getattr(sim, "reward_info", None)
        if ri is not None:
            rec["orig_reward"] = getattr(ri, "reward", None)
        if task is None:
            rec["status"] = "unscorable"; rec["error"] = "task_id not in results.tasks"
            n_err += 1; recs.append(rec); continue
        kw = dict(domain=domain, task=task, simulation=sim,
                  evaluation_type=EvaluationType.ALL, solo_mode=solo_mode)
        if supports_mode and get_communication_mode is not None:
            kw["mode"] = get_communication_mode(results, sim)
        if supports_env_kwargs:
            kw["env_kwargs"] = build_env_kwargs(task)
        if supports_strict and not a.no_strict_replay_off:
            kw["strict_replay"] = False
        try:
            out = evaluate_simulation(**kw)
            rec["reward"] = out.reward
            try:
                rec["breakdown"] = {k: v for k, v in (out.reward_breakdown or {}).items()} \
                    if getattr(out, "reward_breakdown", None) else None
            except Exception:
                rec["breakdown"] = None
        except Exception as e:
            rec["status"] = "unscorable"
            rec["error"] = f"{type(e).__name__}: {str(e)[:300]}"
            n_err += 1
        recs.append(rec)

    meta = {
        "label": a.label,
        "results_file": os.path.abspath(a.results),
        "tau2_version": getattr(tau2, "__version__", None),
        "tau2_module": os.path.dirname(tau2.__file__),
        "data_dir": os.environ.get("TAU2_DATA_DIR"),
        "domain": domain,
        "agent_llm": getattr(results.info.agent_info, "llm", None),
        "user_llm": getattr(results.info.user_info, "llm", None),
        "git_commit": getattr(results.info, "git_commit", None),
        "timestamp": str(getattr(results, "timestamp", None)),
        "num_tasks": len(results.tasks),
        "num_sims": len(results.simulations),
        "fresh_tasks": fresh_report,
        "supports": {"mode": supports_mode, "env_kwargs": supports_env_kwargs,
                     "strict_replay": supports_strict},
        "flags": {"retrieval_variant": a.retrieval_variant, "no_env_kwargs": a.no_env_kwargs, "no_strict_replay_off": a.no_strict_replay_off},
        "n_unscorable": n_err,
        "load_seconds": round(load_s, 1),
        "total_seconds": round(time.time() - t0, 1),
    }
    with open(a.out, "w") as f:
        json.dump({"meta": meta, "records": recs}, f)
    print(json.dumps({k: meta[k] for k in
                      ["label","tau2_version","domain","num_tasks","num_sims",
                       "n_unscorable","total_seconds"]}))

if __name__ == "__main__":
    main()

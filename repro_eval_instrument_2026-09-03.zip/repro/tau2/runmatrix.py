"""Batch driver: rescore each trajectory file under each (code, data, tasks) condition."""
import argparse, glob, json, os, subprocess, sys, time

ROOT = "/PATH/TO/probes/tau2"
SRC = {
    "v0.2.0":     f"{ROOT}/src_v0.2.0/tau2-bench-0.2.0",
    "v1.0.0":     f"{ROOT}/src_v1.0.0/tau2-bench-1.0.0",
    "pre-v1.0.1": f"{ROOT}/src_pre-v1.0.1/tau2-bench-pre-v1.0.1",
    "v1.0.1":     f"{ROOT}/src_v1.0.1/tau2-bench-1.0.1",
}
PY = f"{ROOT}/venv_common/bin/python"

def run(cond, path, outdir):
    name = os.path.basename(path).replace(".json", "")
    out = f"{outdir}/{name}__{cond['name']}.json"
    if os.path.exists(out) and os.path.getsize(out) > 100:
        return out, "cached"
    env = dict(os.environ)
    env["PYTHONPATH"] = SRC[cond["code"]] + "/src"
    env["TAU2_DATA_DIR"] = SRC[cond["data"]] + "/data"
    env["LOGURU_LEVEL"] = "ERROR"
    cmd = [PY, f"{ROOT}/rescore.py", "--results", path, "--out", out, "--label", cond["name"]]
    cmd += cond.get("extra", [])
    if cond.get("retrieval_variant"):
        cmd += ["--retrieval-variant", cond["retrieval_variant"]]
    t = time.time()
    p = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=7200)
    if p.returncode != 0:
        with open(out + ".err", "w") as f:
            f.write(p.stdout[-4000:] + "\n---\n" + p.stderr[-8000:])
        return out, f"FAILED rc={p.returncode} ({time.time()-t:.0f}s)"
    return out, f"ok ({time.time()-t:.0f}s)"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--glob", required=True)
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--conds", required=True, help="comma-separated condition names")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--retrieval-variant", default=None)
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    ALL = {
        "code020":      dict(name="code020",      code="v0.2.0",     data="v0.2.0"),
        "code100":      dict(name="code100",      code="v1.0.0",     data="v1.0.0"),
        "codePRE":      dict(name="codePRE",      code="pre-v1.0.1", data="pre-v1.0.1"),
        "code101":      dict(name="code101",      code="v1.0.1",     data="v1.0.1"),
        "code101fresh": dict(name="code101fresh", code="v1.0.1",     data="v1.0.1", extra=["--fresh-tasks"]),
        # attribution ablations (1.0.1 code)
        "code101_noenvkw":  dict(name="code101_noenvkw",  code="v1.0.1", data="v1.0.1", extra=["--no-env-kwargs"]),
        "code101_strict":   dict(name="code101_strict",   code="v1.0.1", data="v1.0.1", extra=["--no-strict-replay-off"]),
        "code101fresh_noenvkw": dict(name="code101fresh_noenvkw", code="v1.0.1", data="v1.0.1",
                                     extra=["--fresh-tasks", "--no-env-kwargs"]),
        # code/data crossing
        "codePRE_data101": dict(name="codePRE_data101", code="pre-v1.0.1", data="v1.0.1"),
        "code101_dataPRE": dict(name="code101_dataPRE", code="v1.0.1", data="pre-v1.0.1"),
        "code101fresh_dataPRE": dict(name="code101fresh_dataPRE", code="v1.0.1", data="pre-v1.0.1",
                                     extra=["--fresh-tasks"]),
        "code100fresh": dict(name="code100fresh", code="v1.0.0", data="v1.0.0", extra=["--fresh-tasks"]),
        "code020_data100fresh": dict(name="code020_data100fresh", code="v0.2.0", data="v1.0.0", extra=["--fresh-tasks"]),
        "code100_data020fresh": dict(name="code100_data020fresh", code="v1.0.0", data="v0.2.0", extra=["--fresh-tasks"]),
        "codePRE_fresh": dict(name="codePRE_fresh", code="pre-v1.0.1", data="pre-v1.0.1", extra=["--fresh-tasks"]),
    }
    conds = [dict(ALL[c]) for c in a.conds.split(",")]
    if a.retrieval_variant:
        for c in conds:
            c["retrieval_variant"] = a.retrieval_variant
    files = sorted(glob.glob(a.glob))
    jobs = [(c, f) for f in files for c in conds]
    print(f"{len(files)} files x {len(conds)} conditions = {len(jobs)} jobs, workers={a.workers}", flush=True)
    from concurrent.futures import ThreadPoolExecutor
    def work(j):
        c, f = j
        try:
            o, s = run(c, f, a.outdir)
        except Exception as e:
            s = f"EXC {type(e).__name__}: {e}"
        return f"  {os.path.basename(f)[:60]:<62} {c['name']:<22} {s}"
    with ThreadPoolExecutor(max_workers=a.workers) as ex:
        for line in ex.map(work, jobs):
            print(line, flush=True)
    print("MATRIXDONE", flush=True)

if __name__ == "__main__":
    main()

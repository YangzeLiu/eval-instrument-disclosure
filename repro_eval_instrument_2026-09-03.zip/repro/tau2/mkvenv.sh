#!/bin/bash
cd /PATH/TO/probes/tau2/
PY=python3
MIR="-i https://mirrors.aliyun.com/pypi/simple/"
for pair in "v0.2.0:src_v0.2.0/tau2-bench-0.2.0" "v1.0.0:src_v1.0.0/tau2-bench-1.0.0" "pre-v1.0.1:src_pre-v1.0.1/tau2-bench-pre-v1.0.1" "v1.0.1:src_v1.0.1/tau2-bench-1.0.1"; do
  v=${pair%%:*}; d=${pair##*:}
  echo "===== venv_$v from $d ====="
  [ -d venv_$v ] || $PY -m venv venv_$v
  ./venv_$v/bin/pip install -q --upgrade pip $MIR 2>&1 | tail -2
  ./venv_$v/bin/pip install -q -e "$d" $MIR 2>&1 | tail -15
  echo "-- tau2 --help:"; ./venv_$v/bin/tau2 --help 2>&1 | tail -25
  echo "-- evaluate-trajs --help:"; ./venv_$v/bin/tau2 evaluate-trajs --help 2>&1 | tail -30
done
echo ALLDONE

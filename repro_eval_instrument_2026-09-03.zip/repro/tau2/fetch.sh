#!/bin/bash
cd /PATH/TO/probes/tau2/
echo "=== try plain git clone (120s) ==="
timeout 120 git clone --quiet https://github.com/sierra-research/tau2-bench.git repo 2>&1 | tail -3
if [ -d repo/.git ]; then echo "CLONE_OK"; cd repo && git log --oneline -1 && git tag | tail -20; else echo "CLONE_FAILED"; rm -rf repo; fi

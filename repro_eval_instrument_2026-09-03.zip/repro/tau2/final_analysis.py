"""Consolidate re-scoring matrix -> transitions.json + printed tables."""
import json, glob, os, sys, itertools, collections

ROOT = "/PATH/TO/probes/tau2"


def load(outdir):
    """-> {file_stem: {cond: {(task_id,trial): rec}}}, plus meta"""
    data = collections.defaultdict(dict)
    meta = collections.defaultdict(dict)
    for f in sorted(glob.glob(os.path.join(outdir, "*.json"))):
        base = os.path.basename(f)[:-5]
        if "__" not in base:
            continue
        stem, cond = base.rsplit("__", 1)
        try:
            d = json.load(open(f))
        except Exception:
            continue
        recs = {}
        for r in d["records"]:
            recs[(r["task_id"], r["trial"])] = r
        data[stem][cond] = recs
        meta[stem][cond] = d["meta"]
    return data, meta


def p1(recs):
    ok = [r for r in recs.values() if r["status"] == "ok"]
    return (sum(r["reward"] for r in ok) / len(ok), len(ok), len(recs) - len(ok)) if ok else (float("nan"), 0, len(recs))


def orig_p1(recs):
    v = [r["orig_reward"] for r in recs.values() if r["orig_reward"] is not None]
    return sum(v) / len(v) if v else float("nan")


def pairwise(a, b):
    """paired stats on sims scorable in BOTH."""
    keys = [k for k in a if k in b]
    both = [k for k in keys if a[k]["status"] == "ok" and b[k]["status"] == "ok"]
    m = {"pp": 0, "pf": 0, "fp": 0, "ff": 0}
    flip_tasks = collections.Counter()
    flip_sims = []
    for k in both:
        ra, rb = a[k]["reward"], b[k]["reward"]
        pa, pb = ra >= 1.0, rb >= 1.0
        if pa and pb:
            m["pp"] += 1
        elif pa and not pb:
            m["pf"] += 1
            flip_tasks[k[0]] += 1
            flip_sims.append({"task": k[0], "trial": k[1], "dir": "p->f", "ra": ra, "rb": rb})
        elif (not pa) and pb:
            m["fp"] += 1
            flip_tasks[k[0]] += 1
            flip_sims.append({"task": k[0], "trial": k[1], "dir": "f->p", "ra": ra, "rb": rb})
        else:
            m["ff"] += 1
    na = sum(a[k]["reward"] for k in both) / len(both) if both else float("nan")
    nb = sum(b[k]["reward"] for k in both) / len(both) if both else float("nan")
    return {
        "n_common": len(both),
        "n_keys": len(keys),
        "unscorable_A": sum(1 for k in keys if a[k]["status"] != "ok"),
        "unscorable_B": sum(1 for k in keys if b[k]["status"] != "ok"),
        "matrix": m,
        "paired_p1_A": round(na, 6),
        "paired_p1_B": round(nb, 6),
        "paired_delta_pp": round((nb - na) * 100, 4),
        "n_flip_tasks": len(flip_tasks),
        "flip_tasks": dict(flip_tasks),
        "flip_sims": flip_sims,
    }


def ranking_flips(scores_a, scores_b):
    models = sorted(set(scores_a) & set(scores_b))
    flips = []
    n = 0
    for x, y in itertools.combinations(models, 2):
        a, b = scores_a[x] - scores_a[y], scores_b[x] - scores_b[y]
        n += 1
        if a == 0 or b == 0:
            continue
        if (a > 0) != (b > 0):
            flips.append([x, y, round(scores_a[x], 4), round(scores_a[y], 4), round(scores_b[x], 4), round(scores_b[y], 4)])
    return n, flips


def main():
    outdirs = sys.argv[1:] or ["scores_bank", "scores_arts"]
    blob = {}
    for od in outdirs:
        data, meta = load(os.path.join(ROOT, od))
        conds = sorted({c for s in data.values() for c in s})
        print("\n" + "=" * 100)
        print("### %s   files=%d conds=%s" % (od, len(data), conds))
        # per-file per-cond table
        rows = {}
        for stem in sorted(data):
            rows[stem] = {}
            line = [stem[:52].ljust(54), "orig=%.4f" % orig_p1(next(iter(data[stem].values())))]
            for c in conds:
                if c in data[stem]:
                    v, nok, nun = p1(data[stem][c])
                    rows[stem][c] = (v, nok, nun)
                    line.append("%s=%.4f(ok%d,x%d)" % (c[:16], v, nok, nun))
            print(" ".join(line))
        # pairwise
        pairs = []
        for i in range(len(conds)):
            for j in range(i + 1, len(conds)):
                pairs.append((conds[i], conds[j]))
        agg = {}
        for (ca, cb) in pairs:
            per = {}
            tot = collections.Counter()
            for stem in sorted(data):
                if ca in data[stem] and cb in data[stem]:
                    r = pairwise(data[stem][ca], data[stem][cb])
                    per[stem] = r
                    for k, v in r["matrix"].items():
                        tot[k] += v
            if not per:
                continue
            deltas = [r["paired_delta_pp"] for r in per.values()]
            nflip = sum(r["n_flip_tasks"] for r in per.values())
            agg["%s->%s" % (ca, cb)] = {"per_file": per, "total_matrix": dict(tot),
                                        "mean_delta_pp": round(sum(deltas) / len(deltas), 3),
                                        "min_delta_pp": min(deltas), "max_delta_pp": max(deltas),
                                        "total_flip_task_instances": nflip}
            if tot["pf"] or tot["fp"]:
                print("  %-42s pp=%-5d pf=%-4d fp=%-4d ff=%-5d  meanD=%+.2fpp [%+.2f,%+.2f]" %
                      (ca + " -> " + cb, tot["pp"], tot["pf"], tot["fp"], tot["ff"],
                       sum(deltas) / len(deltas), min(deltas), max(deltas)))
        # ranking flips per condition pair, using paired p1 over sims scorable in both
        rk = {}
        for (ca, cb) in pairs:
            sa, sb = {}, {}
            for stem in sorted(data):
                if ca in data[stem] and cb in data[stem]:
                    r = pairwise(data[stem][ca], data[stem][cb])
                    sa[stem] = r["paired_p1_A"]
                    sb[stem] = r["paired_p1_B"]
            if len(sa) >= 2:
                n, fl = ranking_flips(sa, sb)
                rk["%s->%s" % (ca, cb)] = {"n_pairs": n, "n_flips": len(fl), "flips": fl}
                if fl:
                    print("  RANK FLIP %s -> %s : %d/%d" % (ca, cb, len(fl), n))
                    for f in fl:
                        print("      %s(%.4f->%.4f) vs %s(%.4f->%.4f)" % (f[0][:34], f[2], f[4], f[1][:34], f[3], f[5]))
        blob[od] = {"per_file_p1": {s: {c: list(v) for c, v in r.items()} for s, r in rows.items()},
                    "pairs": agg, "ranking": rk,
                    "meta": {s: {c: m for c, m in mm.items()} for s, mm in meta.items()}}
    with open(os.path.join(ROOT, "transitions.json"), "w") as f:
        json.dump(blob, f, indent=1)
    print("\nwrote transitions.json")


if __name__ == "__main__":
    main()

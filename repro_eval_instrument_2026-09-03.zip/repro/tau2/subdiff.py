import json, statistics
rows = json.load(open("submission_diffs.json"))
out = []
for r in rows:
    a = r["before"]["results"]["banking_knowledge"]
    b = r["after"]["results"]["banking_knowledge"]
    va = r["before"]["methodology"].get("tau2_bench_version")
    vb = r["after"]["methodology"].get("tau2_bench_version")
    out.append(dict(sub=r["dir"], p1b=a["pass_1"], p1a=b["pass_1"], d1=b["pass_1"]-a["pass_1"],
                    p2b=a.get("pass_2"), p2a=b.get("pass_2"),
                    p4b=a.get("pass_4"), p4a=b.get("pass_4"), verb=va, vera=vb))
hdr = "%-44s %9s %9s %8s %9s %9s %10s %8s" % ("submission","p1_before","p1_after","delta","p4_before","p4_after","ver_before","ver_aft")
print(hdr)
for o in sorted(out, key=lambda z: -z["d1"]):
    print("%-44s %9.2f %9.2f %+8.2f %9.2f %9.2f %10s %8s" % (
        o["sub"], o["p1b"], o["p1a"], o["d1"],
        o["p4b"] if o["p4b"] is not None else float("nan"),
        o["p4a"] if o["p4a"] is not None else float("nan"), o["verb"], o["vera"]))
d = [o["d1"] for o in out]
print("n=%d mean_delta=%.2f median=%.2f max=%.2f min=%.2f" % (len(d), statistics.mean(d), statistics.median(d), max(d), min(d)))
pairs = flips = 0
for i in range(len(out)):
    for j in range(i+1, len(out)):
        x, y = out[i], out[j]
        pairs += 1
        if (x["p1b"]-y["p1b"]) * (x["p1a"]-y["p1a"]) < 0:
            flips += 1
            print("  FLIP:", x["sub"], "vs", y["sub"], round(x["p1b"],2), round(y["p1b"],2), "->", round(x["p1a"],2), round(y["p1a"],2))
print("pairwise orderings=%d flipped=%d (%.1f%%)" % (pairs, flips, 100.0*flips/pairs))
print("rank_before:", [o["sub"] for o in sorted(out, key=lambda z:-z["p1b"])])
print("rank_after :", [o["sub"] for o in sorted(out, key=lambda z:-z["p1a"])])
json.dump(out, open("official_leaderboard_delta.json","w"), indent=1)
